import Cocoa

//1

func addNumber(num1: Int, num2: Int) -> Int {
    var sum = num1 + num2
    print (sum)
    return sum
}
addNumber(num1: 4, num2: 3)


func delitionNmuber(num1: Int, num2: Int) -> Int {
    var delition = num1 - num2
    print (delition)
    return delition
}
delitionNmuber(num1: 4, num2: 5)

func multiplicationNumber(num1: Int, num2: Int) -> Int {
    var multiplication = num1 * num2
    print (multiplication)
    return multiplication
}
multiplicationNumber(num1: 3, num2: 7)

func divisionNumber(num1: Float, num2: Float) -> Float {
    var devision: Float = num1 / num2
    print (devision)
    return devision
}
divisionNumber(num1: 47, num2: 21)

func remainderOfDevisionNumber(num1: Int, num2: Int) -> Int {
    var remainderOfDevisionNumber = num1 % num2
    print (remainderOfDevisionNumber)
    return remainderOfDevisionNumber
}
remainderOfDevisionNumber(num1: 10, num2: 3)




